package com.manuelpeinado.fadingactionbar.view;


public interface ObservableScrollable {
    void setOnScrollChangedCallback(OnScrollChangedCallback callback);
}
