package com.manuelpeinado.fadingactionbar.view;

public interface OnScrollChangedCallback {
    void onScroll(int l, int t);
}
